/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at http://mozilla.org/MPL/2.0/. */

/*---ZennoLab was here---*/
 
//@line 8 "s:\Sources\ZennoPoster\Master\XulRunner\45\xulrunner\app\xulrunner.js"

// We need to override the default values of these preferences since all.js
// assumes these are in the navigator package, which for us is nonexistent.
// XXX(darin): perhaps all.js should not be seamonkey specific
pref("general.useragent.locale", "en-US");
pref("xpinstall.dialog.confirm", "chrome://mozapps/content/xpinstall/xpinstallConfirm.xul");
pref("xpinstall.dialog.progress.chrome", "chrome://mozapps/content/extensions/extensions.xul");
pref("xpinstall.dialog.progress.skin", "chrome://mozapps/content/extensions/extensions.xul");
pref("xpinstall.dialog.progress.type.chrome", "Extension:Manager");
pref("xpinstall.dialog.progress.type.skin", "Extension:Manager");
pref("xpinstall.enabled", true);
//@line 20 "s:\Sources\ZennoPoster\Master\XulRunner\45\xulrunner\app\xulrunner.js"
pref("browser.preferences.instantApply", false);
//@line 27 "s:\Sources\ZennoPoster\Master\XulRunner\45\xulrunner\app\xulrunner.js"
pref("browser.preferences.animateFadeIn", false);
//@line 29 "s:\Sources\ZennoPoster\Master\XulRunner\45\xulrunner\app\xulrunner.js"

pref("browser.cache.offline.enable", false);
pref("browser.cache.memory.capacity", 102400);
pref("browser.cache.memory.max_entry_size", 5120);
pref("browser.cache.disk.smart_size.enabled", true);
pref("browser.cache.disk.smart_size.first_run", false);
pref("browser.cache.disk.smart_size.use_old_max", false);
pref("browser.cache.disk.smart_size_cached_value", 358400);
pref("browser.cache.memory.enable", true);
pref("browser.cache.disk.capacity", 358400);
pref("browser.cache.disk.enable", false);

pref("content.max.tokenizing.time", 2250000);
pref("content.notify.backoffcount", 5);
pref("content.notify.interval", 750000);
pref("content.notify.ontimer", true);
pref("content.switch.threshold", 750000);
pref("nglayout.initialpaint.delay", 750);
pref("network.http.max-connections", 16);
pref("network.http.max-connections-per-server", 8);
pref("network.http.max-persistent-connections-per-proxy", 8);
pref("network.http.max-persistent-connections-per-server", 8);
pref("network.http.pipelining", false);
pref("network.http.proxy.pipelining", false);
pref("network.http.pipelining.maxrequests", 1);
pref("network.prefetch-next", false);
pref("network.dns.disablePrefetch", true);
pref("network.http.speculative-parallel-limit", 0);
pref("network.predictor.enabled", false);
pref("network.dns.disableIPv6", false);
pref("network.http.fast-fallback-to-IPv4", true);
pref("network.cookie.maxNumber", 9999999);
pref("network.cookie.maxPerHost", 99999);
pref("network.cookie.purgeAge", 2147483647); 
pref("plugins.force.wmode", "opaque");
pref("signon.prefillForms", false);
pref("signon.rememberSignons", false);
pref("general.buildID.override", "20130215130331");
pref("extensions.blocklist.enabled", false);
pref("dom.ipc.plugins.enabled", false);
pref("network.security.ports.banned", "port1935");
pref("network.proxy.socks_remote_dns", true);
pref("network.proxy.share_proxy_settings", true);
pref("browser.download.manager.showWhenStarting", false);
pref("browser.download.manager.showAlertOnComplete", false);
pref("dom.gamepad.enabled", true);
pref("security.csp.speccompliant", true); 
pref("security.ssl.enable_ocsp_stapling", true); 
pref("services.sync.prefs.sync.security.OCSP.enabled", true); 
pref("services.sync.prefs.sync.security.OCSP.require", true);
pref("security.default_personal_cert", "Select Automatically");
pref("dom.netinfo.enabled", true);
pref("dom.permissions.enabled", true);
pref("dom.serviceWorkers.enabled", true);
pref("dom.presentation.enabled", true);
pref("media.eme.apiVisible", true);
pref("media.wmf.enabled", false);
pref("network.http.spdy.enabled.http2", false);
pref("network.http.spdy.enabled.http2draft", false); 

// WebRTC settings
pref("media.peerconnection.enabled", false);
pref("media.navigator.enabled", true);
pref("media.navigator.permission.disabled", true);